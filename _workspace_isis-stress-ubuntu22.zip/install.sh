#!/bin/bash

# ========================================
# isis stress - Ubuntu 22 Installer
# ========================================

echo "=========================================="
echo "  isis stress - Ubuntu 22 Setup"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Kør venligst som root: sudo bash install.sh"
  exit 1
fi

# Update system
echo "[1/6] Opdaterer system..."
apt update && apt upgrade -y

# Install Node.js 20.x
echo "[2/6] Installerer Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Verify Node.js installation
node --version
npm --version

# Create application directory
echo "[3/6] Opretter applikationsmappe..."
APP_DIR="/var/www/isis-stress"
mkdir -p $APP_DIR

# Copy files
if [ -d "./server" ]; then
  cp -r ./server $APP_DIR/
  cp -r ./public $APP_DIR/
  echo "Filer kopieret til $APP_DIR"
else
  echo "Advarsel: Ingen filer fundet i nuværende mappe."
  echo "Sørg for at server/ og public/ mapperne findes."
  exit 1
fi

# Install npm dependencies
echo "[4/6] Installerer npm afhængigheder..."
cd $APP_DIR/server
npm install --production

# Set permissions
echo "[5/6] Sætter rettigheder..."
chown -R www-data:www-data $APP_DIR
chmod -R 755 $APP_DIR

# Create systemd service
echo "[6/6] Opretter systemd service..."
cat > /etc/systemd/system/isis-stress.service <<'EOF'
[Unit]
Description=isis stress
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/isis-stress/server
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=isis-stress
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
systemctl daemon-reload
systemctl enable isis-stress
systemctl start isis-stress

# Configure firewall
echo ""
echo "Konfigurerer firewall..."
if command -v ufw >/dev/null 2>&1; then
  ufw allow 3000/tcp
  ufw allow 22/tcp
  ufw --force enable 2>/dev/null
fi

# Check status
sleep 2
if systemctl is-active --quiet isis-stress; then
  echo ""
  echo "=========================================="
  echo "  INSTALLATION KOMPLET!"
  echo "=========================================="
  echo ""
  echo "Applikationen kører på: http://SERVER_IP:3000"
  echo ""
  echo "Standard login:"
  echo "  Brugernavn: admin"
  echo "  Adgangskode: admin123"
  echo ""
  echo "Nyttige kommandoer:"
  echo "  Status:    systemctl status isis-stress"
  echo "  Stop:      systemctl stop isis-stress"
  echo "  Start:     systemctl start isis-stress"
  echo "  Logs:      journalctl -u isis-stress -f"
  echo ""
  echo "Database: $APP_DIR/server/network_test.db"
  echo "=========================================="
else
  echo ""
  echo "ADVARSEL: Servicen kunne ikke startes."
  echo "Tjek logs: journalctl -u isis-stress -n 50"
fi