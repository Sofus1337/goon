const db = require('./database');

// Get all API endpoints (admin only)
function getAllEndpoints(req, res) {
  try {
    const endpoints = db.prepare(`
      SELECT ae.*, tm.name as method_name
      FROM api_endpoints ae
      LEFT JOIN test_methods tm ON ae.method_id = tm.id
      ORDER BY ae.method_id, ae.priority
    `).all();

    // Mask API keys for security
    const maskedEndpoints = endpoints.map(ep => ({
      ...ep,
      api_key: ep.api_key ? ep.api_key.substring(0, 8) + '****' : null
    }));
    res.json(maskedEndpoints);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Get endpoints by method
function getEndpointsByMethod(req, res) {
  const { methodId } = req.params;
  try {
    const endpoints = db.prepare('SELECT * FROM api_endpoints WHERE method_id = ? AND is_active = 1 ORDER BY priority').all(methodId);
    const maskedEndpoints = endpoints.map(ep => ({
      ...ep,
      api_key: ep.api_key ? ep.api_key.substring(0, 8) + '****' : null
    }));
    res.json(maskedEndpoints);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Get single endpoint
function getEndpoint(req, res) {
  const { id } = req.params;
  try {
    const endpoint = db.prepare('SELECT * FROM api_endpoints WHERE id = ?').get(id);
    if (!endpoint) {
      return res.status(404).json({ error: 'API endpoint ikke fundet.' });
    }
    endpoint.api_key = endpoint.api_key ? endpoint.api_key.substring(0, 8) + '****' : null;
    res.json(endpoint);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Create API endpoint (admin only)
function createEndpoint(req, res) {
  const { method_id, api_url, username, api_key, priority, is_active } = req.body;

  if (!api_url) {
    return res.status(400).json({ error: 'API URL er påkrævet.' });
  }

  try {
    const result = db.prepare(
      'INSERT INTO api_endpoints (method_id, api_url, username, api_key, priority, is_active) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(method_id || null, api_url, username || null, api_key || null, priority || 1, is_active !== undefined ? (is_active ? 1 : 0) : 1);

    const endpoint = db.prepare('SELECT * FROM api_endpoints WHERE id = ?').get(result.lastInsertRowid);
    endpoint.api_key = endpoint.api_key ? endpoint.api_key.substring(0, 8) + '****' : null;
    res.status(201).json(endpoint);
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved oprettelse af API endpoint.' });
  }
}

// Update API endpoint (admin only)
function updateEndpoint(req, res) {
  const { id } = req.params;
  const { method_id, api_url, username, api_key, priority, is_active } = req.body;

  if (!api_url) {
    return res.status(400).json({ error: 'API URL er påkrævet.' });
  }

  try {
    // First get the existing endpoint to preserve api_key if not provided
    const existing = db.prepare('SELECT * FROM api_endpoints WHERE id = ?').get(id);
    
    if (!existing) {
      return res.status(404).json({ error: 'API endpoint ikke fundet.' });
    }

    const finalApiKey = api_key || existing.api_key;

    const result = db.prepare(
      'UPDATE api_endpoints SET method_id = ?, api_url = ?, username = ?, api_key = ?, priority = ?, is_active = ? WHERE id = ?'
    ).run(method_id || null, api_url, username || null, finalApiKey, priority || 1, is_active !== undefined ? (is_active ? 1 : 0) : 1, id);

    const endpoint = db.prepare('SELECT * FROM api_endpoints WHERE id = ?').get(id);
    endpoint.api_key = endpoint.api_key ? endpoint.api_key.substring(0, 8) + '****' : null;
    res.json(endpoint);
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved opdatering af API endpoint.' });
  }
}

// Delete API endpoint (admin only)
function deleteEndpoint(req, res) {
  const { id } = req.params;

  try {
    const result = db.prepare('DELETE FROM api_endpoints WHERE id = ?').run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: 'API endpoint ikke fundet.' });
    }
    res.json({ message: 'API endpoint slettet succesfuldt!' });
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved sletning af API endpoint.' });
  }
}

module.exports = {
  getAllEndpoints,
  getEndpointsByMethod,
  getEndpoint,
  createEndpoint,
  updateEndpoint,
  deleteEndpoint
};