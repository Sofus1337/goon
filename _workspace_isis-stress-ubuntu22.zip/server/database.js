const initSqlJs = require('sql.js');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'network_test.db');

let db = null;

// Initialize database
async function initDatabase() {
  const SQL = await initSqlJs();
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  console.log('Connected to SQLite database');

  // Create tables
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      plan_type TEXT DEFAULT 'none',
      credits_used INTEGER DEFAULT 0,
      credit_limit INTEGER DEFAULT 100,
      plan_expires_at DATETIME,
      is_blocked INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS test_methods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      icon TEXT,
      color TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS api_endpoints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      method_id INTEGER,
      api_url TEXT NOT NULL,
      username TEXT,
      api_key TEXT,
      priority INTEGER DEFAULT 1,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (method_id) REFERENCES test_methods(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS test_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      method_id INTEGER,
      target_address TEXT,
      port INTEGER,
      duration INTEGER,
      status TEXT,
      result_data TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (method_id) REFERENCES test_methods(id)
    )
  `);

  console.log('Database tables created successfully');
  seedInitialData();
  saveDatabase();
}

function saveDatabase() {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }
}

function seedInitialData() {
  // Check if admin exists
  const adminResult = db.exec("SELECT id FROM users WHERE username = 'admin'");
  
  if (adminResult.length === 0 || adminResult[0].values.length === 0) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    db.run(`
      INSERT INTO users (username, email, password, role, plan_type, credit_limit, plan_expires_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now', '+365 days'))
    `, ['admin', 'admin@networktest.com', hashedPassword, 'super_admin', 'vip', 0]);
    console.log('Default admin user created');
  }

  // Seed test methods
  const methodsResult = db.exec("SELECT COUNT(*) as count FROM test_methods");
  const methodsCount = methodsResult.length > 0 ? methodsResult[0].values[0][0] : 0;
  
  if (methodsCount === 0) {
    const testMethods = [
      { name: 'TCP Flood', description: 'TCP pakke oversvømmelse test', icon: '🌊', color: '#ef4444' },
      { name: 'UDP Flood', description: 'UDP pakke oversvømmelse test', icon: '📡', color: '#f97316' },
      { name: 'HTTP GET', description: 'HTTP GET anmodning test', icon: '🌐', color: '#22c55e' },
      { name: 'HTTP POST', description: 'HTTP POST anmodning test', icon: '📝', color: '#3b82f6' },
      { name: 'SYN Flood', description: 'SYN pakke oversvømmelse test', icon: '⚡', color: '#8b5cf6' },
      { name: 'ICMP Ping', description: 'ICMP ping test', icon: '🔔', color: '#ec4899' },
      { name: 'Bandwidth Test', description: 'Båndbredde belastningstest', icon: '📊', color: '#14b8a6' }
    ];

    for (const method of testMethods) {
      db.run('INSERT INTO test_methods (name, description, icon, color) VALUES (?, ?, ?, ?)',
        [method.name, method.description, method.icon, method.color]);
    }
    console.log('Test methods seeded');
  }

  // Seed API endpoints
  const endpointsResult = db.exec("SELECT COUNT(*) as count FROM api_endpoints");
  const endpointsCount = endpointsResult.length > 0 ? endpointsResult[0].values[0][0] : 0;
  
  if (endpointsCount === 0) {
    const methodsResult = db.exec('SELECT id FROM test_methods');
    if (methodsResult.length > 0) {
      methodsResult[0].values.forEach((row, index) => {
        const methodId = row[0];
        db.run('INSERT INTO api_endpoints (method_id, api_url, username, api_key, priority) VALUES (?, ?, ?, ?, ?)',
          [methodId, `https://api.example${index + 1}.com/test`, `user_${index + 1}`, `key_${Date.now()}`, 1]);
      });
      console.log('API endpoints seeded');
    }
  }
}

// Helper functions for database operations
function prepare(sql) {
  return {
    run: function(...params) {
      try {
        db.run(sql, params);
        saveDatabase();
        // Get the last inserted row ID from the database
        const result = db.exec("SELECT last_insert_rowid()");
        const rowId = result.length > 0 && result[0].values.length > 0 ? result[0].values[0][0] : 0;
        const changesResult = db.exec("SELECT changes()");
        const changes = changesResult.length > 0 && changesResult[0].values.length > 0 ? changesResult[0].values[0][0] : 0;
        return { lastInsertRowid: rowId, changes: changes };
      } catch (err) {
        console.error('SQL Error:', err);
        console.error('SQL:', sql);
        console.error('Params:', params);
        throw err;
      }
    },
    get: function(...params) {
      const stmt = db.prepare(sql);
      stmt.bind(params);
      if (stmt.step()) {
        const row = stmt.getAsObject();
        stmt.free();
        return row;
      }
      stmt.free();
      return undefined;
    },
    all: function(...params) {
      const results = [];
      const stmt = db.prepare(sql);
      stmt.bind(params);
      while (stmt.step()) {
        results.push(stmt.getAsObject());
      }
      stmt.free();
      return results;
    }
  };
}

function exec(sql) {
  db.run(sql);
  saveDatabase();
}

let lastInsertId = 0;

function getLastInsertId() {
  return lastInsertId;
}

function setLastInsertId(id) {
  lastInsertId = id;
}

function getChanges() {
  const result = db.exec("SELECT changes()");
  return result.length > 0 ? result[0].values[0][0] : 0;
}

// Export a promise that resolves to the db interface
module.exports = {
  init: initDatabase,
  prepare,
  exec,
  saveDatabase
};