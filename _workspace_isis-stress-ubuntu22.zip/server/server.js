const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');
const auth = require('./auth');
const testMethods = require('./testMethods');
const apiEndpoints = require('./apiEndpoints');
const networkTest = require('./networkTest');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ============ AUTH ROUTES ============
app.post('/api/auth/login', auth.login);
app.post('/api/auth/register', auth.register);
app.get('/api/auth/me', auth.authenticateToken, auth.getCurrentUser);
app.put('/api/auth/password', auth.authenticateToken, auth.changePassword);

// ============ USER MANAGEMENT (Admin) ============
app.get('/api/users', auth.authenticateToken, auth.requireAdmin, (req, res) => {
  try {
    const users = db.prepare(`
      SELECT id, username, email, role, plan_type, credits_used, credit_limit, 
             plan_expires_at, is_blocked, created_at, last_login
      FROM users
      ORDER BY id
    `).all();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
});

app.post('/api/users', auth.authenticateToken, auth.requireAdmin, (req, res) => {
  const { username, email, password, role, plan_type, credit_limit, plan_expires_at } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Brugernavn og adgangskode er påkrævet.' });
  }

  const hashedPassword = auth.hashPassword(password);

  try {
    const result = db.prepare(`
      INSERT INTO users (username, email, password, role, plan_type, credit_limit, plan_expires_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(username, email || null, hashedPassword, role || 'user', plan_type || 'none', credit_limit || 100, plan_expires_at || null);

    const user = db.prepare('SELECT id, username, email, role, plan_type, credits_used, credit_limit, plan_expires_at, is_blocked, created_at FROM users WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(user);
  } catch (err) {
    if (err.message && err.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: 'Brugernavnet er allerede i brug.' });
    }
    res.status(500).json({ error: 'Fejl ved oprettelse af bruger.' });
  }
});

app.put('/api/users/:id', auth.authenticateToken, auth.requireAdmin, (req, res) => {
  const { id } = req.params;
  const { role, plan_type, credit_limit, plan_expires_at, is_blocked, email } = req.body;

  try {
    // Build dynamic update query
    const updates = [];
    const values = [];

    if (role !== undefined) { updates.push('role = ?'); values.push(role); }
    if (plan_type !== undefined) { updates.push('plan_type = ?'); values.push(plan_type); }
    if (credit_limit !== undefined) { updates.push('credit_limit = ?'); values.push(credit_limit); }
    if (plan_expires_at !== undefined) { updates.push('plan_expires_at = ?'); values.push(plan_expires_at); }
    if (is_blocked !== undefined) { updates.push('is_blocked = ?'); values.push(is_blocked ? 1 : 0); }
    if (email !== undefined) { updates.push('email = ?'); values.push(email); }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'Ingen felter at opdatere.' });
    }

    values.push(id);
    const result = db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Bruger ikke fundet.' });
    }

    const user = db.prepare('SELECT id, username, email, role, plan_type, credits_used, credit_limit, plan_expires_at, is_blocked, created_at FROM users WHERE id = ?').get(id);
    res.json(user);
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Fejl ved opdatering af bruger.' });
  }
});

// Update user password (admin only)
app.put('/api/users/:id/password', auth.authenticateToken, auth.requireAdmin, (req, res) => {
  const { id } = req.params;
  const { password } = req.body;

  if (!password || password.length < 6) {
    return res.status(400).json({ error: 'Adgangskode skal være mindst 6 tegn.' });
  }

  try {
    const hashedPassword = auth.hashPassword(password);
    const result = db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Bruger ikke fundet.' });
    }

    res.json({ message: 'Adgangskode opdateret.' });
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved opdatering af adgangskode.' });
  }
});

app.delete('/api/users/:id', auth.authenticateToken, auth.requireSuperAdmin, (req, res) => {
  const { id } = req.params;
  try {
    const result = db.prepare('DELETE FROM users WHERE id = ?').run(id);
    if (result.changes === 0) {
      return res.status(404).json({ error: 'Bruger ikke fundet.' });
    }
    res.json({ message: 'Bruger slettet succesfuldt!' });
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved sletning af bruger.' });
  }
});

// ============ TEST METHODS ROUTES ============
app.get('/api/methods', testMethods.getAllMethods);
app.get('/api/methods/active', testMethods.getActiveMethods);
app.get('/api/methods/stats', auth.authenticateToken, auth.requireAdmin, testMethods.getMethodsWithStats);
app.get('/api/methods/:id', testMethods.getMethod);
app.post('/api/methods', auth.authenticateToken, auth.requireAdmin, testMethods.createMethod);
app.put('/api/methods/:id', auth.authenticateToken, auth.requireAdmin, testMethods.updateMethod);
app.delete('/api/methods/:id', auth.authenticateToken, auth.requireAdmin, testMethods.deleteMethod);

// ============ API ENDPOINTS ROUTES ============
app.get('/api/endpoints', auth.authenticateToken, auth.requireAdmin, apiEndpoints.getAllEndpoints);
app.get('/api/endpoints/method/:methodId', auth.authenticateToken, apiEndpoints.getEndpointsByMethod);
app.get('/api/endpoints/:id', auth.authenticateToken, auth.requireAdmin, apiEndpoints.getEndpoint);
app.post('/api/endpoints', auth.authenticateToken, auth.requireAdmin, apiEndpoints.createEndpoint);
app.put('/api/endpoints/:id', auth.authenticateToken, auth.requireAdmin, apiEndpoints.updateEndpoint);
app.delete('/api/endpoints/:id', auth.authenticateToken, auth.requireAdmin, apiEndpoints.deleteEndpoint);

// ============ NETWORK TEST ROUTES ============
app.post('/api/test', auth.authenticateToken, networkTest.startTest);
app.get('/api/test/history', auth.authenticateToken, networkTest.getTestHistory);
app.get('/api/test/results', auth.authenticateToken, auth.requireAdmin, networkTest.getAllTestResults);
app.get('/api/statistics', networkTest.getStatistics);

// ============ SERVE FRONTEND ============
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Catch-all for SPA routing
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Noget gik galt på serveren.' });
});

// Initialize database and start server
async function startServer() {
  try {
    await db.init();
    console.log('Database initialized');
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`http://0.0.0.0:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();

module.exports = app;