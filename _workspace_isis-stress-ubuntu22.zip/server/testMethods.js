const db = require('./database');

// Get all test methods
function getAllMethods(req, res) {
  try {
    const methods = db.prepare('SELECT * FROM test_methods ORDER BY id').all();
    res.json(methods);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Get active test methods
function getActiveMethods(req, res) {
  try {
    const methods = db.prepare('SELECT * FROM test_methods WHERE is_active = 1 ORDER BY id').all();
    res.json(methods);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Get single test method
function getMethod(req, res) {
  const { id } = req.params;
  try {
    const method = db.prepare('SELECT * FROM test_methods WHERE id = ?').get(id);
    if (!method) {
      return res.status(404).json({ error: 'Test metode ikke fundet.' });
    }
    res.json(method);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

// Create test method (admin only)
function createMethod(req, res) {
  const { name, description, icon, color, is_active } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Metode navn er påkrævet.' });
  }

  try {
    const result = db.prepare(
      'INSERT INTO test_methods (name, description, icon, color, is_active) VALUES (?, ?, ?, ?, ?)'
    ).run(name, description || '', icon || '🔧', color || '#8b5cf6', is_active !== undefined ? (is_active ? 1 : 0) : 1);

    const method = db.prepare('SELECT * FROM test_methods WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(method);
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved oprettelse af test metode.' });
  }
}

// Update test method (admin only)
function updateMethod(req, res) {
  const { id } = req.params;
  const { name, description, icon, color, is_active } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Metode navn er påkrævet.' });
  }

  try {
    const result = db.prepare(
      'UPDATE test_methods SET name = ?, description = ?, icon = ?, color = ?, is_active = ? WHERE id = ?'
    ).run(name, description || '', icon || '🔧', color || '#8b5cf6', is_active !== undefined ? (is_active ? 1 : 0) : 1, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Test metode ikke fundet.' });
    }

    const method = db.prepare('SELECT * FROM test_methods WHERE id = ?').get(id);
    res.json(method);
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved opdatering af test metode.' });
  }
}

// Delete test method (admin only)
function deleteMethod(req, res) {
  const { id } = req.params;

  try {
    const result = db.prepare('DELETE FROM test_methods WHERE id = ?').run(id);
    
    if (result.changes === 0) {
      return res.status(404).json({ error: 'Test metode ikke fundet.' });
    }
    res.json({ message: 'Test metode slettet succesfuldt!' });
  } catch (err) {
    res.status(500).json({ error: 'Fejl ved sletning af test metode.' });
  }
}

// Get method with endpoint count
function getMethodsWithStats(req, res) {
  try {
    const methods = db.prepare(`
      SELECT tm.*, 
             (SELECT COUNT(*) FROM api_endpoints WHERE method_id = tm.id) as endpoint_count
      FROM test_methods tm
      ORDER BY tm.id
    `).all();
    res.json(methods);
  } catch (err) {
    res.status(500).json({ error: 'Database fejl.' });
  }
}

module.exports = {
  getAllMethods,
  getActiveMethods,
  getMethod,
  createMethod,
  updateMethod,
  deleteMethod,
  getMethodsWithStats
};