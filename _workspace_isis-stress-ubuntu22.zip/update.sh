#!/bin/bash
# Opdatering af isis stress

echo "Stopper serveren..."
sudo systemctl stop isis-stress

echo "Sletter gamle filer..."
sudo rm -rf /var/www/isis-stress/server
sudo rm -rf /var/www/isis-stress/public

echo "Kopierer nye filer..."
sudo cp -r server /var/www/isis-stress/
sudo cp -r public /var/www/isis-stress/

echo "Installerer afhængigheder..."
cd /var/www/isis-stress/server
sudo npm install --production

echo "Sætter rettigheder..."
sudo chown -R www-data:www-data /var/www/isis-stress
sudo chmod -R 755 /var/www/isis-stress

echo "Genstarter serveren..."
sudo systemctl start isis-stress

echo "Tjekker status..."
sleep 2
sudo systemctl status isis-stress

echo ""
echo "Færdig! Tjek http://DIN_SERVER_IP:3000"